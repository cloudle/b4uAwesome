export const IncreaseCounter                = '@APP:INCREASE-COUNTER';
