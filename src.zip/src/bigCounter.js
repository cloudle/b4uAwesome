import React, { Component } from 'react';
import { StyleSheet, View, Text, } from 'react-native';

type Props = {
	counter?: Number,
};

export default class BigCounter extends Component {
	props: Props;

	render() {
		return <View style={styles.container}>
			<Text style={{ fontSize: 30,}} >{this.props.counter}</Text>
		</View>;
	}
}

const styles = StyleSheet.create({
	container: {

	},
});
