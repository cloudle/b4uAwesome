import React, { Component } from 'react';
import { StyleSheet, View, Text, } from 'react-native';
import { Button } from 'react-universal-ui';

import SmallCounter from './smallCounter';
import BigCounter from './bigCounter';

type Props = {
	counter?: Number,
	onIncrease?: Function,
};

export default class Counter extends Component {
	props: Props;

	constructor(props) {
		super(props);
		this.state = {
			internalCounter: 0,
		};
	}

	componentDidMount() {
		setInterval(() => {
			this.setState({ internalCounter: this.state.internalCounter + 1 })
		}, 200)
	}

	render() {
		return <View style={styles.container}>
			<BigCounter counter={this.props.counter}/>
			<SmallCounter counter={this.state.internalCounter}/>
			<Button title="Hey" onPress={() => {
				const nextInternalCounter = this.state.internalCounter + 1;
				if (nextInternalCounter > 10) {
					this.props.onIncrease(this.state.internalCounter / 2);
					this.setState({ internalCounter: 0 });
				} else {
					this.setState({ internalCounter: this.state.internalCounter + 1})
				}
			}}/>
		</View>;
	}
}

const styles = StyleSheet.create({
	container: {

	},
});
