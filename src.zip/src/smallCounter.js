import React, { Component } from 'react';
import { StyleSheet, View, Text, } from 'react-native';

type Props = {
	counter?: Number,
};

export default class SmallCounter extends Component {
	props: Props;

	render() {
		return <View style={styles.container}>
			<Text>{this.props.counter}</Text>
		</View>;
	}
}

const styles = StyleSheet.create({
	container: {

	},
});
